import React from 'react';
import { useBlobContext, SavedBlob } from '../../context/BlobContext';
import { useBlob } from '../../hooks/useBlob';
import { Trash2, ExternalLink, Heart } from 'lucide-react';

export default function Gallery() {
  const { savedBlobs, deleteBlob, loadBlob, toggleLike, user } = useBlobContext();

  if (savedBlobs.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-12 border-2 border-dashed border-white/5 rounded-2xl">
        <p className="text-slate-500 text-xs uppercase tracking-widest">Meus Designs</p>
        <p className="text-slate-600 text-[10px] mt-1 text-center px-4">
          {user ? 'Você ainda não salvou nenhum design.' : 'Faça login para ver sua galeria.'}
        </p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-3 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
      {savedBlobs.map((blob) => (
        <GalleryItem 
          key={blob.id} 
          blob={blob} 
          onDelete={() => deleteBlob(blob.id)} 
          onLoad={() => loadBlob(blob)}
          onLike={() => toggleLike(blob.id)}
        />
      ))}
    </div>
  );
}

interface GalleryItemProps {
  blob: SavedBlob;
  onDelete: () => void;
  onLoad: () => void;
  onLike: () => void;
  key?: any;
}

function GalleryItem({ blob, onDelete, onLoad, onLike }: GalleryItemProps) {
  const path = useBlob({ complexity: blob.complexity, smoothness: blob.smoothness, seed: blob.seed });

  return (
    <div className="group relative glass-hover glass rounded-xl p-3 flex flex-col gap-2 transition-all">
      <div className="aspect-square w-full flex items-center justify-center bg-black/20 rounded-lg overflow-hidden relative">
        <svg viewBox="0 0 200 200" className="w-full h-full drop-shadow-lg">
          <path fill={blob.color} d={path} />
        </svg>
        
        {/* Like Badge */}
        <div className="absolute bottom-1 right-1 flex items-center gap-1 bg-black/40 backdrop-blur-md px-1.5 py-0.5 rounded-full border border-white/5">
          <Heart size={10} className="text-red-500 fill-red-500" />
          <span className="text-[9px] font-bold text-white">{blob.likesCount || 0}</span>
        </div>
      </div>
      
      <div className="flex justify-between items-center">
        <span className="text-[10px] font-mono text-slate-400 uppercase">{blob.color}</span>
        <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <button 
            onClick={onLike}
            className="p-1.5 hover:bg-red-500/20 text-red-500 rounded-md transition-colors"
            title="Like"
          >
            <Heart size={12} />
          </button>
          <button 
            onClick={onLoad}
            className="p-1.5 hover:bg-blob-blue/20 text-blob-blue rounded-md transition-colors"
            title="Carregar"
          >
            <ExternalLink size={12} />
          </button>
          <button 
            onClick={onDelete}
            className="p-1.5 hover:bg-red-500/20 text-red-500 rounded-md transition-colors"
            title="Excluir"
          >
            <Trash2 size={12} />
          </button>
        </div>
      </div>
    </div>
  );
}
